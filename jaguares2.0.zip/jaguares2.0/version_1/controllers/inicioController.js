const bcrypt = require('bcrypt');
const db = require('../config/db');

exports.registro = async(req, res)=>{
    console.log(req.body);
    const {nombre, contrasenia, correo, numero, cumpleanios}= req.body;
    
    if (!nombre || !contrasenia || !correo || !numero || !cumpleanios) {
        return res.status(400).send('Todos los campos son requeridos');
    }
    try{
        
        const hashedPassword= await bcrypt.hash(contrasenia,10);
        //Ingertmos al usuario a la base de datos
        console.log(nombre, correo, numero, cumpleanios, hashedPassword)
        const query= 'INSERT INTO registro (email, user_name, telefono, fecha_nacimiento, contrasenia) VALUES (?,?,?,?,?)';
        db.query(query, [correo, nombre, numero, cumpleanios, hashedPassword], (err, result)=>{
        if(err){
            if(err.code==='ER_DUP_ENTRY'){
                return res.status(400).send('El nombre de usuario ya existe');
            }
            console.error('Error en la consulta:', err);
                // Resto del manejo de errores...
            
            return res.status(500).send('Error en el servidor');    
        }
        res.redirect('/login');
    });
    }catch(error){
        console.error('Error en el registro: ', error);
        res.status(500).send('Error en el servidor');
    }
};

exports.login = async (req, res)=>{
    const {nombre,contrasenia}= req.body;
    console.log("login: ",req.body);
    if(!nombre || !contrasenia){
        return res.status(400).send('Todos los campos son requeridos');
    }
    const query='SELECT * FROM registro WHERE user_name = ?';
    db.query(query,[nombre], async(err, results)=>{
        if(err){
            console.error('Error en la consulta: ', err);
            return res.status(500).send('Error en el servidor');
        }
        if(results.length===0){
            return res.status(400).send('Usuario no encontrado');
        }
        const usuario= results[0];
        try{
            const coincide = await bcrypt.compare(contrasenia, usuario.contrasenia);
            if(coincide){
                req.session.nombre=usuario.nombre;
                res.redirect('/formularioia');
            }else{
                res.status(400).send('Contraseña incorrecta');
            }
        }catch(error){
            console.error('Error al comparar contraseñas: ',error);
            res.status(500).send('Error en el servidor');
        }
    });
};

exports.logout=(req, res)=>{
    req.session.destroy((err)=>{
        if(err){
            console.error('Error al cerrar sesión: ', err);
            return res.status(500).send('Error en el servidor');
        }
        res.redirect('/login');
    });
};