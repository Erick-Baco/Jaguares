// Archivo: server.js

const express = require('express');
const path = require('path');
const { DiscoveryEngineClient } = require('@google-cloud/discoveryengine');
const { GoogleAuth } = require('google-auth-library');
const vertexai = require('@google-cloud/aiplatform');

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Conectar con la base de datos
const { Pool } = require('pg');
const pool = new Pool({
    user: 'root',
    host: 'localhost',
    database: 'usuarios',
    password: '131404',
    port: 8806,
});

// Rutas
const perfilRouter = require('./routes/perfil_router');
app.use('/', perfilRouter);

// Google Cloud Configuration
const PROJECT_ID = 'super-test-438512';
const LOCATION = 'us-central1';
const DATA_STORE_ID = 'data-alimentacion_1728822635018';

// Inicializar Google Auth y el cliente de Discovery Engine
const auth = new GoogleAuth({
    keyFile: '/Users/erickbaco/Downloads/super-test-438512-047ac6b34d09.json',
    scopes: ['https://www.googleapis.com/auth/cloud-platform'],
});

let client;
(async () => {
    client = new DiscoveryEngineClient({
        auth: await auth.getClient(),
        projectId: PROJECT_ID,
    });
})();

// Inicializar Vertex AI
vertexai.init({
    projectId: PROJECT_ID,
    location: LOCATION,
});

// Ruta para búsqueda personalizada y clasificación
app.post('/search', async (req, res) => {
    const perfil = req.body.perfil;

    // Verificar si los datos del perfil fueron enviados correctamente
    if (!perfil) {
        return res.status(400).json({ error: 'No se proporcionó el perfil del usuario' });
    }

    // Define la configuración del servicio de búsqueda
    const servingConfig = `projects/${PROJECT_ID}/locations/${LOCATION}/dataStores/${DATA_STORE_ID}/servingConfigs/default_config`;

    // Define la consulta de búsqueda basada en el perfil del usuario
    const query = `Buscar información personalizada para el usuario con el objetivo: ${perfil.objetivo}, plazo: ${perfil.plazo}, ingresos: ${perfil.ingresos}`;

    // Crea la solicitud de búsqueda
    const request = {
        servingConfig,
        query,
    };

    // Realiza la petición y procesa la respuesta
    try {
        const [response] = await client.search(request);
        const searchResults = response.results.map(result => result.document.content);

        // Preparar el prompt para generar el resumen con Gemini
        const prompt = `
    Eres un experto en finanzas personales. Clasifica al usuario según la información proporcionada:

    Objetivo: ${perfil.objetivo}
    Plazo: ${perfil.plazo}
    Ingresos: ${perfil.ingresos}

    Devuelve una sola palabra para clasificar al usuario: "principiante", "intermedio" o "avanzado".
    Asegúrate de devolver la respuesta en español.
    `;

        // Crear el cliente de Vertex AI y el modelo generativo
        const model = new vertexai.generativeModels.TextGenerationModel('gemini-1.5-flash-002');

        // Generar la clasificación del nivel del usuario
        const summary = await model.generate({
            prompt,
            maxOutputTokens: 5,
        });

        res.json({ nivel: summary.text.trim() });
    } catch (e) {
        console.error('Error en la búsqueda personalizada:', e);
        res.status(500).json({ error: e.message });
    }
});

// Iniciar el servidor
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
