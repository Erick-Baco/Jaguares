// Archivo: public/js/script.js

document.addEventListener('DOMContentLoaded', function () {
    // Obtenemos la referencia al botón de obtener recomendaciones
    const obtenerRecomendacionesBtn = document.getElementById('obtener-recomendaciones');
    const userId = 123; // Cambia este ID según el usuario correspondiente

    // Función para obtener los datos del perfil del usuario desde la base de datos
    async function obtenerPerfilUsuario(userId) {
        try {
            const response = await fetch('/perfil', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ userId }),
            });

            if (!response.ok) {
                throw new Error('Error en la solicitud: ' + response.status);
            }

            const perfil = await response.json();
            return perfil; // Retorna el perfil del usuario
        } catch (error) {
            console.error('Error al obtener el perfil del usuario:', error);
        }
    }

    // Función para enviar los datos del perfil a la API para obtener el nivel del usuario
    async function obtenerNivelUsuario(perfil) {
        try {
            const response = await fetch('/search', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ perfil }),
            });

            if (!response.ok) {
                throw new Error('Error en la solicitud: ' + response.status);
            }

            const data = await response.json();
            return data.nivel; // Retorna 'principiante', 'intermedio' o 'avanzado'
        } catch (error) {
            console.error('Error al obtener el nivel del usuario:', error);
        }
    }

    // Función para mostrar u ocultar los elementos de la página según el nivel del usuario
    function mostrarElementosSegunNivel(nivel) {
        const niveles = ['principiante', 'intermedio', 'avanzado'];

        niveles.forEach(n => {
            const elementos = document.querySelectorAll(`.${n}`);
            if (n !== nivel) {
                // Ocultar elementos que no correspondan al nivel del usuario
                elementos.forEach(el => el.style.display = 'none');
            } else {
                // Mostrar los elementos correspondientes al nivel del usuario
                elementos.forEach(el => el.style.display = 'block');
            }
        });
    }

    // Evento que se ejecuta cuando se hace clic en el botón de obtener recomendaciones
    obtenerRecomendacionesBtn.addEventListener('click', async function () {
        const perfil = await obtenerPerfilUsuario(userId);
        if (perfil) {
            const nivel = await obtenerNivelUsuario(perfil);
            if (nivel) {
                mostrarElementosSegunNivel(nivel);
            }
        }
    });
});
