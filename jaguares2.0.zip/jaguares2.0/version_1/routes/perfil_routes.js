// Archivo: routes/perfil_router.js

const express = require('express');
const router = express.Router();
const { Pool } = require('pg'); // Puedes usar mysql o mariadb si prefieres

// Configuración de la base de datos
const pool = new Pool({
    user: 'root',
    host: 'localhost',
    database: 'usuarios',
    password: '131404',
    port: 8806,
});

// Ruta para obtener el perfil del usuario
router.post('/perfil', async (req, res) => {
    const { userId } = req.body;

    if (!userId) {
        return res.status(400).json({ error: 'No se proporcionó el id del usuario' });
    }

    try {
        const result = await pool.query('SELECT * FROM perfil WHERE user_id = $1', [userId]);

        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'No se encontró un perfil para el id proporcionado' });
        }

        res.status(200).json(result.rows[0]);
    } catch (error) {
        console.error('Error al obtener el perfil del usuario:', error);
        res.status(500).json({ error: 'Error al obtener los datos del usuario' });
    }
});

module.exports = router;
