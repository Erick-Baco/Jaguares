const express = require('express');
const router = express.Router();
const authController = require('../controller/inicioController');

router.get('/', (req,res)=>{
    res.redirect('/login')
})
//Mostrar formulario de registro
router.get('/registro', (req, res)=>{
    res.render('registro');
});
router.get('/inicio', (req,res)=>{
    res.render('inicio');
})

//Procesar registro
router.post('/registro', authController.registro);

//Mostrar formulario de inicio de sesión
router.get('/login',(req,res)=>{
    res.render('login');
});

//Procesar INicio de seción
router.post('/login', authController.login);

router.post('/logout', authController.logout);

module.exports=router;