const path = require("path");
const express = require("express");
const app = express();

// Configurar el middleware para archivos estáticos
app.use(express.static(path.join(__dirname, "public")));

// Definir una ruta para servir un archivo HTML
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

const PORT = process.env.PORT || 2800; // Cambiar a un puerto disponible como 5000
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});

